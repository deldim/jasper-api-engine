-- Drop the sequence and trigger if they exist
BEGIN
    EXECUTE IMMEDIATE 'DROP SEQUENCE users_seq';
EXCEPTION
    WHEN OTHERS THEN
        NULL;
END;
/

BEGIN
    EXECUTE IMMEDIATE 'DROP TRIGGER users_trigger';
EXCEPTION
    WHEN OTHERS THEN
        NULL;
END;
/

-- Drop the table if it exists
BEGIN
    EXECUTE IMMEDIATE 'DROP TABLE users';
EXCEPTION
    WHEN OTHERS THEN
        NULL;
END;
/

-- Create the table
CREATE TABLE users (
    id NUMBER PRIMARY KEY,
    name VARCHAR2(100) NOT NULL,
    email VARCHAR2(100) UNIQUE NOT NULL
);

-- Create the sequence
CREATE SEQUENCE users_seq START WITH 1 INCREMENT BY 1;

-- Create the trigger
CREATE TRIGGER users_trigger 
BEFORE INSERT ON users 
FOR EACH ROW 
BEGIN
    :NEW.id := users_seq.NEXTVAL;
END;
/

-- Insert dummy data
INSERT INTO users (name, email) VALUES ('Alice Smith', 'alice@example.com');
INSERT INTO users (name, email) VALUES ('Bob Johnson', 'bob@example.com');
INSERT INTO users (name, email) VALUES ('Charlie Brown', 'charlie.brown@example.com');
INSERT INTO users (name, email) VALUES ('Dana White', 'dana@example.org');
INSERT INTO users (name, email) VALUES ('Eve Adams', 'eve@sample.net');

-- Commit the transaction
COMMIT;
